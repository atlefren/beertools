from brewerynamematcher_test import *
from beernamematcher_test import *

if __name__ == '__main__':
    unittest.main()
